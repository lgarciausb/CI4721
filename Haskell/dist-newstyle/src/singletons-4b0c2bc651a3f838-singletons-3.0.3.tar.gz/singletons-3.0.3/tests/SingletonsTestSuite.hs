-- | Currently, there is code to execute at runtime as a part of this test
-- suite, as the only interesting part is making sure that the code typechecks.
module Main (main) where

main :: IO ()
main = pure ()
