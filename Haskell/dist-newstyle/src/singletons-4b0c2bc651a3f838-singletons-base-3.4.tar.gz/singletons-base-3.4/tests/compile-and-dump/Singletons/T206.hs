module T206 where

import Prelude.Singletons

x = SCons @Bool @True @'[False]
